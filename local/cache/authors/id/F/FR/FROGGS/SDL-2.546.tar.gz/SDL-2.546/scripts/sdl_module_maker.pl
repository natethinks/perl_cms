use strict;
use warnings;
use lib 'lib';
use Module::Build::SDL;

Module::Build::SDL::generate_sdl_module( @ARGV );

