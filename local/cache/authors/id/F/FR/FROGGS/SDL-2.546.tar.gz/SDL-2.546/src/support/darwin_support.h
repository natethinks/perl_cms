void init_ns_application();
void quit_ns_application();

