/*
 * Controller Timer Header
 */


typedef struct TIMER {
 
	int started_ticks;
	int paused_ticks;
	int started;
	int paused;

} sdlx_timer;
