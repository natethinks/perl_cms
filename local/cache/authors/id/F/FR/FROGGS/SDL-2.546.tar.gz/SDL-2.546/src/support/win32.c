

#ifdef MSWIN32
int dummy()
{
	return 0;
}
#endif
